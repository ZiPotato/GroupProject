﻿/***********************************************************************************************

Tämä on esimerkki matkahuollon osoitekorttihaun rajapinnan käytöstä.
Luokka sisältää perustoiminnot xml-viestien lähettämiseen ja vastaanottoon sekä
PDF-tiedoston generointiin. Kaikki muut mahdolliset lähetysviestiin liitettävät arvot 
(katso dokumentaatio) ovat mukana, paitsi useamman paketin käsittely sekä arvojen loogisuus-
tarkistukset.

************************************************************************************************/

using System;
using System.Net;
using System.IO;
using System.Xml;
using System.Web;


namespace WebApplication1
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /* Luodaan matkahuolto luokka ja asetetaan arvot. Esimerkissä vain pakolliset kentät */


            Matkahuolto mh = new Matkahuolto();
 
            mh.pUserId = "09430023";
            mh.Password = "456";
            mh.Version = "1.0";
            mh.MessageType = "N";
            mh.Weight = "3.25";
            mh.Packages = "2";
            mh.SenderId = "09430023";
            mh.ReceiverName1 = "Eetun lafka";
            mh.ReceiverPostal = "00520";
            mh.ReceiverCity = "HELSINKI";
            mh.ProductCode = "30";
      
            /* lähetetään xml-sanoma. Arvona vastaanottava palvelinosoite */
            mh.sendXML("https://mhhkiweb1.matkahuolto.fi/scripts101c/mhshipmentxmltesti.wsc/ovtinxml");

            /* jos ei virheitä luodaan pdf-tiedosto */
            if (mh.ErrorNbr == "")
            {
                mh.showPDF(mh.ShipmentPdf);
            }
        }


/* Matkahuolto luokka ***********************************************************************/
   
        public class Matkahuolto
        {

            /* Lähetyssanoman arvot */

            private string puserId = "";
            public string pUserId
            {
                get { return this.puserId; }
                set { puserId = value; }
            }

            private string password = "";
            public string Password
            {
                get { return this.password; }
                set { password = value; }
            }

            private string version = "";
            public string Version
            {
                get { return this.version; }
                set { version = value; }
            }

            private string messageType = "";
            public string MessageType
            {
                get { return this.messageType; }
                set { messageType = value; }
            }

            private string shipmentNumber = "";
            public string ShipmentNumber
            {
                get { return this.shipmentNumber; }
                set { shipmentNumber = value; }
            }

            private string shipmentDate = "";
            public string ShipmentDate
            {
                get { return this.shipmentDate; }
                set { shipmentDate = value; }
            }

            private string weight = "";
            public string Weight
            {
                get { return this.weight; }
                set { weight = value; }
            }

            private string volume = "";
            public string Volume
            {
                get { return this.volume; }
                set { volume = value; }
            }

            private string packages = "";
            public string Packages
            {
                get { return this.packages; }
                set { packages = value; }
            }

            private string senderId = "";
            public string SenderId
            {
                get { return this.senderId; }
                set { senderId = value; }
            }

            private string senderName1 = "";
            public string SenderName1
            {
                get { return this.senderName1; }
                set { senderName1 = value; }
            }

            private string senderName2 = "";
            public string SenderName2
            {
                get { return this.senderName2; }
                set { senderName2 = value; }
            }

            private string senderAddress = "";
            public string SenderAddress
            {
                get { return this.senderAddress; }
                set { senderAddress = value; }
            }

            private string senderPostal = "";
            public string SenderPostal
            {
                get { return this.senderPostal; }
                set { senderPostal = value; }
            }

            private string senderCity = "";
            public string SenderCity
            {
                get { return this.senderCity; }
                set { senderCity = value; }
            }

            private string senderContactName = "";
            public string SenderContactName
            {
                get { return this.senderContactName; }
                set { senderContactName = value; }
            }

            private string senderContactNumber = "";
            public string SenderContactNumber
            {
                get { return this.senderContactNumber; }
                set { senderContactNumber = value; }
            }

            private string senderEmail = "";
            public string SenderEmail
            {
                get { return this.senderEmail; }
                set { senderEmail = value; }
            }

            private string senderReference = "";
            public string SenderReference
            {
                get { return this.senderReference; }
                set { senderReference = value; }
            }

            private string departurePlaceCode = "";
            public string DeparturePlaceCode
            {
                get { return this.departurePlaceCode; }
                set { departurePlaceCode = value; }
            }

            private string departurePlaceName = "";
            public string DeparturePlaceName
            {
                get { return this.DeparturePlaceName; }
                set { departurePlaceName = value; }
            }

            private string receiverId = "";
            public string ReceiverId
            {
                get { return this.receiverId; }
                set { receiverId = value; }
            }

            private string receiverName1 = "";
            public string ReceiverName1
            {
                get { return this.receiverName1; }
                set { receiverName1 = value; }
            }

            private string receiverName2 = "";
            public string ReceiverName2
            {
                get { return this.receiverName2; }
                set { receiverName2 = value; }
            }

            private string receiverAddress = "";
            public string ReceiverAddress
            {
                get { return this.receiverAddress; }
                set { receiverAddress = value; }
            }

            private string receiverPostal = "";
            public string ReceiverPostal
            {
                get { return this.receiverPostal; }
                set { receiverPostal = value; }
            }

            private string receiverCity = "";
            public string ReceiverCity
            {
                get { return this.receiverCity; }
                set { receiverCity = value; }
            }

            private string receiverContactName = "";
            public string ReceiverContactName
            {
                get { return this.receiverContactName; }
                set { receiverContactName = value; }
            }

            private string receiverContactNumber = "";
            public string ReceiverContactNumber
            {
                get { return this.receiverContactNumber; }
                set { receiverContactNumber = value; }
            }

            private string receiverEmail = "";
            public string ReceiverEmail
            {
                get { return this.receiverEmail; }
                set { receiverEmail = value; }
            }

            private string receiverReference = "";
            public string ReceiverReference
            {
                get { return this.receiverReference; }
                set { receiverReference = value; }
            }

            private string destinationPlaceCode = "";
            public string DestinationPlaceCode
            {
                get { return this.destinationPlaceCode; }
                set { destinationPlaceCode = value; }
            }

            private string destinationPlaceName = "";
            public string DestinationPlaceName
            {
                get { return this.destinationPlaceName; }
                set { destinationPlaceName = value; }
            }

            private string payerCode = "";
            public string PayerCode
            {
                get { return this.payerCode; }
                set { payerCode = value; }
            }

            private string remarks = "";
            public string Remarks
            {
                get { return this.remarks; }
                set { remarks = value; }
            }

            private string productCode = "";
            public string ProductCode
            {
                get { return this.productCode; }
                set { productCode = value; }
            }

            private string productName = "";
            public string ProductName
            {
                get { return this.productName; }
                set { productName = value; }
            }

            private string pickup = "";
            public string Pickup
            {
                get { return this.pickup; }
                set { pickup = value; }
            }

            private string pickupPayer = "";
            public string PickupPayer
            {
                get { return this.pickupPayer; }
                set { pickupPayer = value; }
            }

            private string pickupRemarks = "";
            public string PickupRemarks
            {
                get { return this.pickupRemarks; }
                set { pickupRemarks = value; }
            }

            private string delivery = "";
            public string Delivery
            {
                get { return this.delivery; }
                set { delivery = value; }
            }

            private string deliveryPayer = "";
            public string DeliveryPayer
            {
                get { return this.deliveryPayer; }
                set { deliveryPayer = value; }
            }

            private string deliveryRemarks = "";
            public string DeliveryRemarks
            {
                get { return this.deliveryRemarks; }
                set { deliveryRemarks = value; }
            }

            private string cODSum = "";
            public string CODSum
            {
                get { return this.cODSum; }
                set { cODSum = value; }
            }

            private string cODCurrency = "";
            public string CODCurrency
            {
                get { return this.cODCurrency; }
                set { cODCurrency = value; }
            }

            private string cODAccount = "";
            public string CODAccount
            {
                get { return this.cODAccount; }
                set { cODAccount = value; }
            }

            private string cODReference = "";
            public string CODReference
            {
                get { return this.cODReference; }
                set { cODReference = value; }
            }

            private string vAKCode = "";
            public string VAKCode
            {
                get { return this.vAKCode; }
                set { vAKCode = value; }
            }

            private string vAKDescription = "";
            public string VAKDescription
            {
                get { return this.vAKDescription; }
                set { vAKDescription = value; }
            }

            private string documentType = "";
            public string DocumentType
            {
                get { return this.documentType; }
                set { documentType = value; }
            }

            private string shipmentRow = "";
            public string ShipmentRow
            {
                get { return this.shipmentRow; }
                set { shipmentRow = value; }
            }

            private string packageId = "";
            public string PackageId
            {
                get { return this.packageId; }
                set { packageId = value; }
            }

            private string goods = "";
            public string Goods
            {
                get { return this.goods; }
                set { goods = value; }
            }

            /* Paluuviesti onnistunut arvot */

            private string pdfName = "";
            public string PdfName
            {
                get { return this.pdfName; }
                set { pdfName = value; }
            }

            private string shipmentPdf = "";
            public string ShipmentPdf
            {
                get { return this.shipmentPdf; }
                set { shipmentPdf = value; }
            }

            /* Virheviestin arvot */

            private string errorNbr = "";
            public string ErrorNbr
            {
                get { return this.errorNbr; }
                set { errorNbr = value; }
            }

            private string errorMsg = "";
            public string ErrorMsg
            {
                get { return this.errorMsg; }
                set { errorMsg = value; }
            }

            /*******************************************************************/

            public void sendXML(string url)
            {
                /* Luodaan lähetettävä XML-Dokumentti. */

                XmlDocument doc = new XmlDocument();
                XmlNode docNode = doc.CreateXmlDeclaration("1.0", "ISO-8859-1", null);
                doc.AppendChild(docNode);

                XmlNode MHShipmentRequest = doc.CreateElement("MHShipmentRequest");
                doc.AppendChild(MHShipmentRequest);

                XmlNode pUserId = doc.CreateElement("pUserId");
                MHShipmentRequest.AppendChild(pUserId);
                pUserId.InnerXml = puserId;

                XmlNode Password = doc.CreateElement("Password");
                MHShipmentRequest.AppendChild(Password);
                Password.InnerXml = password;

                XmlNode Version = doc.CreateElement("Version");
                MHShipmentRequest.AppendChild(Version);
                Version.InnerXml = "1.0";

                XmlNode Shipment = doc.CreateElement("Shipment");
                MHShipmentRequest.AppendChild(Shipment);

                XmlNode MessageType = doc.CreateElement("MessageType");
                Shipment.AppendChild(MessageType);
                MessageType.InnerXml = messageType;

                XmlNode ShipmentNumber = doc.CreateElement("ShipmentNumber");
                Shipment.AppendChild(ShipmentNumber);
                ShipmentNumber.InnerXml = shipmentNumber;

                XmlNode ShipmentDate = doc.CreateElement("ShipmentDate");
                Shipment.AppendChild(ShipmentDate);
                ShipmentDate.InnerXml = shipmentDate;

                XmlNode Weight = doc.CreateElement("Weight");
                Shipment.AppendChild(Weight);
                Weight.InnerXml = weight;

                XmlNode Volume = doc.CreateElement("Volume");
                Shipment.AppendChild(Volume);
                Volume.InnerXml = volume;

                XmlNode Packages = doc.CreateElement("Packages");
                Shipment.AppendChild(Packages);
                Packages.InnerXml = packages;

                XmlNode SenderId = doc.CreateElement("SenderId");
                Shipment.AppendChild(SenderId);
                SenderId.InnerXml = senderId;

                XmlNode SenderName1 = doc.CreateElement("SenderName1");
                Shipment.AppendChild(SenderName1);
                SenderName1.InnerXml = senderName1;

                XmlNode SenderName2 = doc.CreateElement("SenderName2");
                Shipment.AppendChild(SenderName2);
                SenderName2.InnerXml = senderName2;

                XmlNode SenderAddress = doc.CreateElement("SenderAddress");
                Shipment.AppendChild(SenderAddress);
                SenderAddress.InnerXml = senderAddress;

                XmlNode SenderPostal = doc.CreateElement("SenderPostal");
                Shipment.AppendChild(SenderPostal);
                SenderPostal.InnerXml = senderPostal;

                XmlNode SenderCity = doc.CreateElement("SenderCity");
                Shipment.AppendChild(SenderCity);
                SenderCity.InnerXml = senderCity;

                XmlNode SenderContactName = doc.CreateElement("SenderContactName");
                Shipment.AppendChild(SenderContactName);
                SenderContactName.InnerXml = senderContactName;

                XmlNode SenderContactNumber = doc.CreateElement("SenderContactNumber");
                Shipment.AppendChild(SenderContactNumber);
                SenderContactNumber.InnerXml = senderContactNumber;

                XmlNode SenderEmail = doc.CreateElement("SenderEmail");
                Shipment.AppendChild(SenderEmail);
                SenderEmail.InnerXml = senderEmail;

                XmlNode SenderReference = doc.CreateElement("SenderReference");
                Shipment.AppendChild(SenderReference);
                SenderReference.InnerXml = senderReference;

                XmlNode DeparturePlaceCode = doc.CreateElement("DeparturePlaceCode");
                Shipment.AppendChild(DeparturePlaceCode);
                SenderReference.InnerXml = senderReference;

                XmlNode DeparturePlaceName = doc.CreateElement("DeparturePlaceName");
                Shipment.AppendChild(DeparturePlaceName);
                DeparturePlaceName.InnerXml = departurePlaceName;

                XmlNode ReceiverId = doc.CreateElement("ReceiverId");
                Shipment.AppendChild(ReceiverId);
                ReceiverId.InnerXml = receiverId;

                XmlNode ReceiverName1 = doc.CreateElement("ReceiverName1");
                Shipment.AppendChild(ReceiverName1);
                ReceiverName1.InnerXml = receiverName1;

                XmlNode ReceiverName2 = doc.CreateElement("ReceiverName2");
                Shipment.AppendChild(ReceiverName2);
                ReceiverName2.InnerXml = receiverName2;

                XmlNode ReceiverAddress = doc.CreateElement("ReceiverAddress");
                Shipment.AppendChild(ReceiverAddress);
                ReceiverAddress.InnerXml = receiverAddress;

                XmlNode ReceiverPostal = doc.CreateElement("ReceiverPostal");
                Shipment.AppendChild(ReceiverPostal);
                ReceiverPostal.InnerXml = receiverPostal;

                XmlNode ReceiverCity = doc.CreateElement("ReceiverCity");
                Shipment.AppendChild(ReceiverCity);
                ReceiverCity.InnerXml = receiverCity;

                XmlNode ReceiverContactName = doc.CreateElement("ReceiverContactName");
                Shipment.AppendChild(ReceiverContactName);
                ReceiverContactName.InnerXml = receiverContactName;

                XmlNode ReceiverContactNumber = doc.CreateElement("ReceiverContactNumber");
                Shipment.AppendChild(ReceiverContactNumber);
                ReceiverContactNumber.InnerXml = receiverContactNumber;

                XmlNode ReceiverEmail = doc.CreateElement("ReceiverEmail");
                Shipment.AppendChild(ReceiverEmail);
                ReceiverEmail.InnerXml = receiverEmail;

                XmlNode ReceiverReference = doc.CreateElement("ReceiverReference");
                Shipment.AppendChild(ReceiverReference);
                ReceiverReference.InnerXml = receiverReference;

                XmlNode DestinationPlaceCode = doc.CreateElement("DestinationPlaceCode");
                Shipment.AppendChild(DestinationPlaceCode);
                DestinationPlaceCode.InnerXml = destinationPlaceCode;

                XmlNode DestinationPlaceName = doc.CreateElement("DestinationPlaceName");
                Shipment.AppendChild(DestinationPlaceName);
                DestinationPlaceCode.InnerXml = destinationPlaceCode;

                XmlNode PayerCode = doc.CreateElement("PayerCode");
                Shipment.AppendChild(PayerCode);
                PayerCode.InnerXml = payerCode;

                XmlNode Remarks = doc.CreateElement("Remarks");
                Shipment.AppendChild(Remarks);
                Remarks.InnerXml = remarks;

                XmlNode ProductCode = doc.CreateElement("ProductCode");
                Shipment.AppendChild(ProductCode);
                ProductCode.InnerXml = productCode;

                XmlNode ProductName = doc.CreateElement("ProductName");
                Shipment.AppendChild(ProductName);
                ProductName.InnerXml = productName;

                XmlNode Pickup = doc.CreateElement("Pickup");
                Shipment.AppendChild(Pickup);
                Pickup.InnerXml = pickup;

                XmlNode PickupPayer = doc.CreateElement("PickupPayer");
                Shipment.AppendChild(PickupPayer);
                PickupPayer.InnerXml = pickupPayer;

                XmlNode PickupRemarks = doc.CreateElement("PickupRemarks");
                Shipment.AppendChild(PickupRemarks);
                PickupRemarks.InnerXml = pickupRemarks;

                XmlNode Delivery = doc.CreateElement("Delivery");
                Shipment.AppendChild(Delivery);
                Delivery.InnerXml = delivery;

                XmlNode DeliveryPayer = doc.CreateElement("DeliveryPayer");
                Shipment.AppendChild(DeliveryPayer);
                DeliveryPayer.InnerXml = deliveryPayer;

                XmlNode DeliveryRemarks = doc.CreateElement("DeliveryRemarks");
                Shipment.AppendChild(DeliveryRemarks);
                DeliveryRemarks.InnerXml = deliveryRemarks;

                XmlNode CODSum = doc.CreateElement("CODSum");
                Shipment.AppendChild(CODSum);
                CODSum.InnerXml = cODSum;

                XmlNode CODCurrency = doc.CreateElement("CODCurrency");
                Shipment.AppendChild(CODCurrency);
                CODCurrency.InnerXml = cODCurrency;

                XmlNode CODAccount = doc.CreateElement("CODAccount");
                Shipment.AppendChild(CODAccount);
                CODAccount.InnerXml = cODAccount;

                XmlNode CODReference = doc.CreateElement("CODReference");
                Shipment.AppendChild(CODReference);
                CODReference.InnerXml = cODReference;

                XmlNode Goods = doc.CreateElement("Goods");
                Shipment.AppendChild(Goods);
                Goods.InnerXml = goods;

                XmlNode VAKCode = doc.CreateElement("VAKCode");
                Shipment.AppendChild(VAKCode);
                VAKCode.InnerXml = vAKCode;

                XmlNode VAKDescription = doc.CreateElement("VAKDescription");
                Shipment.AppendChild(VAKDescription);
                VAKDescription.InnerXml = vAKDescription;

                XmlNode DocumentType = doc.CreateElement("DocumentType");
                Shipment.AppendChild(DocumentType);
                DocumentType.InnerXml = documentType;

                /* Lähetetään XML */

                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);

                byte[] requestBytes = System.Text.Encoding.ASCII.GetBytes(doc.InnerXml);
                req.Method = "POST";
                req.ContentType = "text/xml";
                req.ContentLength = requestBytes.Length;
                Stream requestStream = req.GetRequestStream();
                requestStream.Write(requestBytes, 0, requestBytes.Length);
                requestStream.Close();

                /* Vastaan otetaan paluuviesti */

                HttpWebResponse res = (HttpWebResponse)req.GetResponse();

                if (res.StatusCode == HttpStatusCode.OK)
                {

                    XmlTextReader reader = new XmlTextReader(new StreamReader(res.GetResponseStream(), System.Text.Encoding.Default));

                   /* Asetetaan paluu viestin arvot */
                    while (reader.Read())
                    {
                        if (reader.NodeType == XmlNodeType.Element)
                        {
                            switch (reader.Name)
                            {
                                case "ShipmentNumber":
                                    this.shipmentNumber = reader.ReadElementContentAsString();
                                    break;
                                case "SenderReference":
                                    this.senderReference = reader.ReadElementContentAsString();
                                    break;
                                case "ShipmentPdf":
                                      this.shipmentPdf = reader.ReadElementContentAsString();
                                    break;
                                case "PdfName":
                                    this.pdfName = reader.ReadElementContentAsString();
                                    break;
                                case "ErrorNbr":
                                    this.errorNbr = reader.ReadElementContentAsString();
                                    break;
                                case "ErrorMsg":
                                    this.errorMsg = reader.ReadElementContentAsString();
                                    break;
                            }
                  
                        }
                    }

                }
                res.Close();

            }


            /* Luodaan PDF-tiedosto */

            public void showPDF(string pdf)
            {

                byte[] filebytes = Convert.FromBase64String(pdf);
                System.Web.HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", this.shipmentNumber + ".pdf"));
                System.Web.HttpContext.Current.Response.BinaryWrite(filebytes);
                System.Web.HttpContext.Current.Response.Flush();
                System.Web.HttpContext.Current.Response.End();


            }


        }

    }

}
